"""Configuration, loaded from the .env file next to this script."""
import os
import secrets
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent


def _load_env(path: Path) -> None:
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


_load_env(BASE_DIR / ".env")

ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
ANTHROPIC_API_URL = os.environ.get("ANTHROPIC_API_URL", "https://api.anthropic.com/v1/messages")
ANSWER_MODEL = os.environ.get("ANSWER_MODEL", "claude-sonnet-5-5")
QUERY_MODEL = os.environ.get("QUERY_MODEL", "claude-haiku-5-5")

# Shared knowledge base: every PDF in this folder (and its subfolders) is indexed for all students.
def _dir(name: str, default: str) -> Path:
    p = Path(os.environ.get(name) or default)
    return (p if p.is_absolute() else BASE_DIR / p).resolve()


DATA_DIR = _dir("DATA_DIR", "data")
# App storage: database + PDFs uploaded through the website.
STORAGE_DIR = _dir("STORAGE_DIR", "storage")
UPLOAD_DIR = STORAGE_DIR / "uploads"
DB_PATH = STORAGE_DIR / "app.db"

TOP_K = int(os.environ.get("TOP_K", "8"))
MAX_UPLOAD_MB = int(os.environ.get("MAX_UPLOAD_MB", "25"))
HOST = os.environ.get("HOST", "127.0.0.1")
PORT = int(os.environ.get("PORT", "5000"))

for d in (DATA_DIR, STORAGE_DIR, UPLOAD_DIR):
    d.mkdir(parents=True, exist_ok=True)

SECRET_KEY = os.environ.get("SECRET_KEY", "")
if not SECRET_KEY:
    key_file = STORAGE_DIR / "secret_key"
    if not key_file.exists():
        key_file.write_text(secrets.token_hex(32), encoding="utf-8")
    SECRET_KEY = key_file.read_text(encoding="utf-8").strip()
