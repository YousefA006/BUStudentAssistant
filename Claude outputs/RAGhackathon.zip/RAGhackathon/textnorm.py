"""Text normalisation and tokenisation for English + Arabic keyword search."""
import re
import unicodedata

_AR_MARKS = re.compile(r"[ؐ-ًؚ-ٰٟۖ-ۭـ]")  # harakat + tatweel
_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")
_TOKEN = re.compile(r"[a-z0-9]+|[ء-ي]+")
_ARABIC_CHAR = re.compile(r"[؀-ۿ]")

EN_STOP = set("""a an the and or but if of to in on at by for with from as is are was were be been being
this that these those it its into than then there here what which who whom whose when where why how
do does did can could should would may might will shall i you he she we they me my your our their
about please tell show give any all some not no yes""".split())
AR_STOP = set("""في من الى على عن مع هذا هذه ذلك تلك التي الذي الذين هو هي هم انا انت نحن ما ماذا متى
اين كيف لماذا هل او ثم قد كان كانت يكون لا لم لن ان اذا كل بعض عند بين حتى ايضا""".split())

_AR_PREFIXES = ("وال", "بال", "كال", "فال", "لل", "ال")
_AR_SUFFIXES = ("ها", "ات", "ان", "ون", "ين", "يه", "ه", "ي")


def _fix_reversed_arabic_line(line: str) -> str:
    """Some PDF extractors return Arabic in visual (reversed) order. Detect and repair it:
    in correct text many words start with 'ال'; in reversed text they end with 'لا'."""
    words = line.split()
    ar = [w.strip(".,:;!?()«»،؛؟") for w in words if _ARABIC_CHAR.search(w)]
    starts = sum(1 for w in ar if w.startswith("ال"))
    ends = sum(1 for w in ar if w.endswith("لا") and not w.startswith("ال"))
    if ends < 1 or ends <= starts:
        return line
    fixed = []
    for w in reversed(words):
        fixed.append(w[::-1] if _ARABIC_CHAR.search(w) and not re.search(r"[A-Za-z0-9]", w) else w)
    return " ".join(fixed)


def clean_text(text: str) -> str:
    """Display-safe clean-up applied to extracted PDF text (keeps diacritics)."""
    text = unicodedata.normalize("NFKC", text)  # turns Arabic presentation forms into normal letters
    text = "\n".join(_fix_reversed_arabic_line(l) for l in text.split("\n"))
    text = text.replace("­", "")
    text = re.sub(r"[ \t ]+", " ", text)
    text = re.sub(r"(\w)-\n(\w)", r"\1\2", text)  # re-join hyphenated English line breaks
    return text


def normalize(text: str) -> str:
    text = unicodedata.normalize("NFKC", text)
    text = _AR_MARKS.sub("", text)
    text = re.sub("[إأآٱ]", "ا", text)
    text = text.replace("ى", "ي").replace("ة", "ه").replace("ؤ", "و").replace("ئ", "ي")
    return text.translate(_DIGITS).lower()


def _stem_ar(tok: str) -> str:
    for p in _AR_PREFIXES:
        if tok.startswith(p) and len(tok) - len(p) >= 3:
            tok = tok[len(p):]
            break
    else:
        if tok.startswith("و") and len(tok) >= 5:
            tok = tok[1:]
    for s in _AR_SUFFIXES:
        if tok.endswith(s) and len(tok) - len(s) >= 3:
            tok = tok[: -len(s)]
            break
    return tok


def _stem_en(tok: str) -> str:
    if len(tok) <= 3 or tok.isdigit():
        return tok
    for suf, rep in (("ies", "y"), ("ing", ""), ("ed", ""), ("es", ""), ("s", "")):
        if tok.endswith(suf) and len(tok) - len(suf) >= 3:
            return tok[: -len(suf)] + rep
    return tok


def tokenize(text: str) -> list[str]:
    out = []
    for tok in _TOKEN.findall(normalize(text)):
        if tok in EN_STOP or tok in AR_STOP:
            continue
        if "ء" <= tok[0] <= "ي":
            tok = _stem_ar(tok)
        else:
            tok = _stem_en(tok)
        if len(tok) >= 2 or tok.isdigit():
            out.append(tok)
    return out


def is_arabic(text: str) -> bool:
    letters = [c for c in text if c.isalpha()]
    if not letters:
        return False
    return sum(1 for c in letters if _ARABIC_CHAR.match(c)) / len(letters) > 0.3
