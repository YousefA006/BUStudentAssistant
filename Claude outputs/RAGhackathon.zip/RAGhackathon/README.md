# Bethlehem University Student Assistant (RAG)

A web app where students create an account, upload PDFs and ask questions in **English or Arabic**.
Answers come **only** from the indexed PDFs. Every answer cites the exact file, page, section and quoted passage, with a link that opens the PDF at that page.
If the documents don't contain the answer, it replies **"I don't know."** (or **"لا أعرف."** for Arabic questions).

## Run it (Windows)
1. Install Python 3.10+ from python.org (tick "Add Python to PATH").
2. Put the university PDFs in the `data` folder.
3. Double-click `run.bat`. The first run installs the packages.
4. Open http://127.0.0.1:5000 and create an account.

Manual start: `python -m venv .venv`, `.venv\Scripts\activate`, `pip install -r requirements.txt`, `python app.py`.

## How it works
| Step | What happens |
|---|---|
| Ingest | PDFs are read page by page (PyMuPDF, with pypdf as a fallback) and split into about 1,200-character passages. A passage never spans two pages, so page numbers are exact. Section headings are detected and stored. Arabic presentation forms and reversed (visual-order) Arabic text are repaired. |
| Search | A BM25 keyword index with Arabic normalisation (alef/yaa/taa-marbuta forms, diacritics, light stemming) and English stemming. |
| Bilingual queries | Claude Haiku rewrites each question into a standalone question plus English **and** Arabic search terms, so an Arabic question can find English documents and the reverse. Results are combined with reciprocal-rank fusion. |
| Answer | The top passages go to Claude Sonnet as `document` blocks with the **Citations API** enabled. Claude must cite every claim. The app then turns the citations into numbered references [1], [2]… showing file, page X of Y, section and the exact quoted text. |
| Grounding guard | No passages found, Claude says it doesn't know, or the answer has no citation: the user gets "I don't know." / "لا أعرف." |

## Documents
- **`data` folder**: shared with every student. Indexed at startup. Use "Rescan folder" after changes.
- **Uploads from the website**: private to the uploader by default. Tick "Share with all students" to make an upload public. Users can delete their own uploads.
- Scanned PDFs (images only) have no text. The app flags them; run them through OCR first.

## Files
`app.py` (web server and API) · `ingest.py` (PDF to page-exact passages) · `search.py` (BM25 and fusion) · `textnorm.py` (Arabic/English normalisation) · `llm.py` (Claude calls, prompts, citations) · `db.py` (SQLite) · `static/` (web UI) · `storage/` (database and uploaded PDFs, created automatically)

## Settings (`.env`)
`ANTHROPIC_API_KEY`, `ANSWER_MODEL`, `QUERY_MODEL`, `DATA_DIR`, `TOP_K`, `MAX_UPLOAD_MB`, `HOST`, `PORT`.
Passwords are stored hashed (Werkzeug PBKDF2). Sessions use a signed cookie whose secret is generated into `storage/secret_key`.
For a public deployment, run behind HTTPS (for example with `waitress` behind a reverse proxy).
