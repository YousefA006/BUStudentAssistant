"""PDF text extraction, chunking (page-exact) and indexing into SQLite."""
import hashlib
import re
from pathlib import Path

from config import DATA_DIR
from textnorm import clean_text

CHUNK_CHARS = 1200
OVERLAP_CHARS = 200

_HEADING_START = re.compile(
    r"^(\d+(\.\d+)*[.)]?\s|[IVXLC]+\.\s|(chapter|section|part|article|appendix|unit)\b|"
    r"(الفصل|الباب|المادة|القسم|الجزء|البند|ملحق)\b)",
    re.IGNORECASE,
)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def extract_pages(path: Path) -> list[str]:
    """Return the text of every page. Prefers PyMuPDF (better Arabic), falls back to pypdf."""
    try:
        import fitz  # PyMuPDF

        with fitz.open(str(path)) as doc:
            return [clean_text(page.get_text("text")) for page in doc]
    except ImportError:
        pass
    from pypdf import PdfReader

    reader = PdfReader(str(path))
    return [clean_text(page.extract_text() or "") for page in reader.pages]


def _is_heading(line: str) -> bool:
    s = line.strip()
    if not 3 <= len(s) <= 90 or s[-1] in ".,;،؛":
        return False
    if _HEADING_START.match(s) and len(s.split()) <= 14:
        return True
    latin = [c for c in s if c.isascii() and c.isalpha()]
    return len(latin) >= 4 and all(c.isupper() for c in latin) and len(s.split()) <= 10


def chunk_pages(pages: list[str]) -> list[dict]:
    """Split pages into overlapping chunks. A chunk never spans two pages, so page numbers are exact."""
    chunks, section = [], None
    for page_no, text in enumerate(pages, start=1):
        lines = [l.strip() for l in text.split("\n") if l.strip()]
        buf, buf_len, buf_section, seq = [], 0, section, 0

        def flush():
            nonlocal seq
            body = "\n".join(buf).strip()
            if len(body) >= 15:
                seq += 1
                chunks.append({"page": page_no, "seq": seq, "section": buf_section, "text": body})

        for line in lines:
            if _is_heading(line):
                section = line
            if buf and buf_len + len(line) > CHUNK_CHARS:
                flush()
                # carry the tail of the previous chunk for context continuity
                tail, tail_len = [], 0
                for prev in reversed(buf):
                    if tail_len + len(prev) > OVERLAP_CHARS:
                        break
                    tail.insert(0, prev)
                    tail_len += len(prev)
                buf, buf_len, buf_section = tail, tail_len, section
            if not buf:
                buf_section = section
            # very long single lines (no line breaks in the PDF) are split on sentence boundaries
            while len(line) > CHUNK_CHARS:
                cut = max(line.rfind(". ", 0, CHUNK_CHARS), line.rfind("。", 0, CHUNK_CHARS),
                          line.rfind("؟ ", 0, CHUNK_CHARS), line.rfind(" ", 0, CHUNK_CHARS))
                cut = cut + 1 if cut > CHUNK_CHARS // 2 else CHUNK_CHARS
                buf.append(line[:cut].strip())
                flush()
                buf, buf_len, buf_section = [], 0, section
                line = line[cut:].strip()
            if line:
                buf.append(line)
                buf_len += len(line) + 1
        if buf:
            flush()
    return chunks


def index_pdf(conn, path: Path, *, filename: str, owner_id, visibility: str, source: str) -> dict:
    """(Re)index one PDF. Returns the document row as a dict."""
    digest = sha256_file(path)
    pages = extract_pages(path)
    chunks = chunk_pages(pages)
    status = "ready" if chunks else "no_text"
    conn.execute("DELETE FROM documents WHERE stored_path = ?", (str(path),))
    cur = conn.execute(
        "INSERT INTO documents (owner_id, visibility, source, filename, stored_path, sha256, pages, chunks, status)"
        " VALUES (?,?,?,?,?,?,?,?,?)",
        (owner_id, visibility, source, filename, str(path), digest, len(pages), len(chunks), status),
    )
    doc_id = cur.lastrowid
    conn.executemany(
        "INSERT INTO chunks (document_id, page, seq, section, text) VALUES (?,?,?,?,?)",
        [(doc_id, c["page"], c["seq"], c["section"], c["text"]) for c in chunks],
    )
    return dict(conn.execute("SELECT * FROM documents WHERE id = ?", (doc_id,)).fetchone())


def sync_data_folder(conn) -> dict:
    """Index new/changed PDFs in DATA_DIR and drop documents whose files were removed."""
    found, added, updated, failed = set(), [], [], []
    for path in sorted(p for p in DATA_DIR.rglob("*") if p.is_file() and p.suffix.lower() == ".pdf"):
        key = str(path)
        found.add(key)
        row = conn.execute("SELECT sha256 FROM documents WHERE stored_path = ?", (key,)).fetchone()
        try:
            if row and row["sha256"] == sha256_file(path):
                continue
            index_pdf(conn, path, filename=str(path.relative_to(DATA_DIR)).replace("\\", "/"),
                      owner_id=None, visibility="shared", source="folder")
            (updated if row else added).append(path.name)
        except Exception as exc:  # a broken PDF must not stop the whole sync
            failed.append(f"{path.name}: {exc}")
    removed = []
    for row in conn.execute("SELECT id, stored_path, filename FROM documents WHERE source = 'folder'").fetchall():
        if row["stored_path"] not in found:
            conn.execute("DELETE FROM documents WHERE id = ?", (row["id"],))
            removed.append(row["filename"])
    conn.commit()
    return {"added": added, "updated": updated, "removed": removed, "failed": failed}
