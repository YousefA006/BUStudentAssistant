@echo off
cd /d "%~dp0"
if not exist .venv (
  echo Creating virtual environment...
  py -3 -m venv .venv || python -m venv .venv
)
call .venv\Scripts\activate.bat
echo Installing requirements...
python -m pip install -q --upgrade pip
python -m pip install -q -r requirements.txt
echo.
echo Starting Bethlehem University Student Assistant...
python app.py
pause
