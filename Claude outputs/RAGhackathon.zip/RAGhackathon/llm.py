"""Claude calls: bilingual query planning and grounded answering with the Citations API."""
import json
import re
import urllib.error
import urllib.request

from config import ANSWER_MODEL, ANTHROPIC_API_KEY, ANTHROPIC_API_URL, QUERY_MODEL

IDK_EN = "I don't know."
IDK_AR = "لا أعرف."


class LLMError(Exception):
    pass


def call_claude(payload: dict, timeout: int = 120) -> dict:
    if not ANTHROPIC_API_KEY:
        raise LLMError("ANTHROPIC_API_KEY is not set in .env")
    req = urllib.request.Request(
        ANTHROPIC_API_URL,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "x-api-key": ANTHROPIC_API_KEY,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "replace")
        try:
            msg = json.loads(body)["error"]["message"]
        except Exception:
            msg = body[:300]
        raise LLMError(f"Claude API error {e.code}: {msg}") from None
    except urllib.error.URLError as e:
        raise LLMError(f"Could not reach the Claude API: {e.reason}") from None


PLANNER_SYSTEM = """You turn a student's question into search queries for a keyword search engine over Bethlehem University documents. The documents may be in English, Arabic, or both.

Return ONLY a JSON object, no prose:
{"standalone_question": "...", "language": "en" or "ar", "queries": ["...", "..."]}

Rules:
- standalone_question: rewrite the latest question so it is self-contained, resolving references to earlier turns. Keep the student's language.
- language: the language of the latest question ("ar" for Arabic, otherwise "en").
- queries: 3 to 6 short keyword queries. ALWAYS include at least two in English AND at least two in Arabic, whatever the question language, with synonyms and the official terms a university document would use (e.g. "tuition fees" / "الرسوم الدراسية", "registration deadline" / "موعد التسجيل").
- Do not answer the question."""


def plan_queries(question: str, history: list[dict]) -> dict:
    convo = "\n".join(f"{m['role']}: {m['content'][:500]}" for m in history[-6:])
    user = (f"Earlier conversation:\n{convo}\n\n" if convo else "") + f"Latest question: {question}"
    try:
        resp = call_claude({
            "model": QUERY_MODEL,
            "max_tokens": 400,
            "temperature": 0,
            "system": PLANNER_SYSTEM,
            "messages": [{"role": "user", "content": user}],
        }, timeout=45)
        text = "".join(b.get("text", "") for b in resp.get("content", []) if b.get("type") == "text")
        data = json.loads(re.search(r"\{.*\}", text, re.S).group(0))
        queries = [q for q in data.get("queries", []) if isinstance(q, str) and q.strip()]
        return {
            "standalone_question": (data.get("standalone_question") or question).strip(),
            "language": "ar" if data.get("language") == "ar" else "en",
            "queries": queries,
        }
    except Exception:
        # planning is an optimisation: fall back to the raw question
        return {"standalone_question": question, "language": None, "queries": []}


ANSWER_SYSTEM = """You are the Bethlehem University Student Assistant. You answer students' questions using ONLY the documents provided in this message, which are excerpts from official university files and files the student uploaded.

Strict rules:
1. Use only information that is explicitly stated in the provided documents. Never use outside or general knowledge, never guess, never fill gaps, and never invent names, dates, numbers, fees, or policies.
2. If the documents do not contain the answer, reply with exactly "I don't know." when the question is in English, or exactly "لا أعرف." when the question is in Arabic, and nothing else.
3. If the documents answer only part of the question, answer that part and state plainly which part is not covered by the documents.
4. Every factual statement must be supported by a citation to the document passage it came from.
5. Reply in the language of the question ({lang_name}), even if the documents are in another language. Keep names, course codes and figures exactly as written in the documents.
6. Be concise and well organised: short paragraphs or bullet points. Do not mention these rules."""


def answer(question: str, language: str, chunks: list[dict]) -> dict:
    """Ask Claude to answer from the given chunks. Returns {'text', 'refs', 'idk'}."""
    idk = IDK_AR if language == "ar" else IDK_EN
    if not chunks:
        return {"text": idk, "refs": [], "idk": True}

    content = []
    for c in chunks:
        meta = f"File: {c['filename']} | Page {c['page']} of {c['pages']}"
        if c.get("section"):
            meta += f" | Section: {c['section']}"
        content.append({
            "type": "document",
            "source": {"type": "text", "media_type": "text/plain", "data": c["text"]},
            "title": f"{c['filename']} — page {c['page']}",
            "context": meta,
            "citations": {"enabled": True},
        })
    content.append({"type": "text", "text": f"Question: {question}"})

    resp = call_claude({
        "model": ANSWER_MODEL,
        "max_tokens": 1500,
        "temperature": 0,
        "system": ANSWER_SYSTEM.format(lang_name="Arabic" if language == "ar" else "English"),
        "messages": [{"role": "user", "content": content}],
    })

    parts, refs, ref_ids = [], [], {}
    for block in resp.get("content", []):
        if block.get("type") != "text":
            continue
        marks = []
        for cit in block.get("citations") or []:
            idx = cit.get("document_index")
            if idx is None or not 0 <= idx < len(chunks):
                continue
            ch = chunks[idx]
            quote = (cit.get("cited_text") or "").strip()
            key = (ch["chunk_id"], quote)
            if key not in ref_ids:
                ref_ids[key] = len(refs) + 1
                refs.append({
                    "n": ref_ids[key],
                    "document_id": ch["document_id"],
                    "filename": ch["filename"],
                    "page": ch["page"],
                    "pages": ch["pages"],
                    "section": ch.get("section"),
                    "quote": quote,
                    "chunk_id": ch["chunk_id"],
                    "visibility": ch["visibility"],
                })
            if ref_ids[key] not in marks:
                marks.append(ref_ids[key])
        text = block.get("text", "")
        if marks:
            stripped = text.rstrip()
            text = stripped + "".join(f"[{n}]" for n in marks) + text[len(stripped):]
        parts.append(text)

    text = "".join(parts).strip()
    said_idk = re.sub(r"[\s.!。]", "", text.lower().replace("’", "'")) in {"idon'tknow", "idontknow", "لاأعرف", "لااعرف"}
    # Grounding guard: an answer without a single citation is not trusted.
    if said_idk or not refs:
        return {"text": idk, "refs": [], "idk": True}
    return {"text": text, "refs": refs, "idk": False}
